import requests
import logging
import random

logging.basicConfig(filename='agent_pi.log',level=logging.DEBUG)

Global_url = "http://127.0.0.1:5000/{}"

def op_unlock_car(username,password ,booking_number,car_number):
    try:
        unlock_car_data= {
        "username":username,
        "password":password,
        "booking_number":booking_number,
        "car_number":car_number,
        }
        url = Global_url.format("car/unlock")
        res = requests.post(url,data = unlock_car_data)
        jdata = res.json()
        logging.info("the res is:%r",jdata)
    except Exception as err:
        jdata = {
            "error":str(err)
        }
    return jdata

def op_return_car(username,password ,booking_number,return_car_number):
    try:
        return_car_data ={
        "username":username,
        "password":password,
        "booking_number":booking_number,
        "return_car_number":return_car_number,
        }
        url = Global_url.format("car/return")
        res = requests.post(url,data = return_car_data)
        jdata = res.json()
        logging.info("the res is:%r",jdata)
    except Exception as err:
        jdata = {
            "error":str(err)
        }
    return jdata

def op_uplocation(username,password ,latitude,longitude):
    try:
        return_car_data ={
        "username":username,
        "password":password,
        "latitude":latitude,
        "longitude":longitude,
        }
        url = Global_url.format("car/location")
        res = requests.post(url,data = return_car_data)
        jdata = res.json()
        logging.info("the res is:%r",jdata)
    except Exception as err:
        jdata = {
            "error":str(err)
        }
    return jdata

def refresh(socket):
    socket.emit(
        "refresh",
        {
            "refresh_token": 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1ODkwODEzMzIsIm5iZiI6MTU4OTA4MTMzMiwianRpIjoiNWFiYzc5ODQtMTMyYi00MWE4LWFmODAtYjIyMGQ1NzI1ZWY2IiwiZXhwIjoxNTkxNjczMzMyLCJpZGVudGl0eSI6InVzZXIiLCJ0eXBlIjoicmVmcmVzaCJ9.If9yQtW_ptRk9vJ2AsmnZ-xqzx1zo1yA_O6LykrObRU'
        },
        callback=refresh_callback,
    )


if __name__ == '__main__':
    main()
# s.disconnect()
