import sys
from agent.sockets.operation import *
# import logging

# logging.basicConfig(filename='agent_pi.log',level=logging.DEBUG)

class Things:
    def __init__(self):
        self.username = ""
        self.password = ""

    def login(self):
        username = input("Please iuput your username:")
        print(username)
        password = input("Please input your password:")
        print(password)
        self.username = username
        self.password = password
        # print("will call the login method")

    def unlock_car(self):
        booking_number = input("Please iuput your booking number:")
        print(booking_number)
        car_number = input("Please iuput your car number:")
        print(car_number)
        print("will call the unlock car method")
        res = op_unlock_car(self.username,self.password ,booking_number,car_number)
        print(res)

    def return_car(self):
        booking_number = input("Please iuput your booking number:")
        print(booking_number)
        return_car_number = input("Please iuput your return car number:")
        print(return_car_number)
        print("will call the return car method")
        res = op_return_car(self.username,self.password ,booking_number,return_car_number)
        print(res)

class Menu:
    def __init__(self):
        self.thing = Things()
        self.choices = {
            "1": self.thing.login,
            "2": self.thing.unlock_car,
            "3": self.thing.return_car,
            "4": self.quit,
        }
        # self.choices = {
        #     # "1": self.thing.login,
        #     "1": self.thing.unlock_car,
        #     "2": self.thing.return_car,
        #     "3": self.quit,
        # }

    def display_menu(self):
        print(
            """
                 Operation Menu:
                 1. Login
                 2. Unlock Car
                 3. Return Car
                 4. Quit"""
        )
        # print(
        #     """
        #          Operation Menu:
        #          1. Unlock Car
        #          2. Return Car
        #          3. Quit"""
        # )

    def run(self):
        while True:
            refresh()
            self.display_menu()
            try:
                choice = input("Enter an option: ")
            except Exception:
                print("Please input a valid option!")
                continue

            choice = str(choice).strip()
            action = self.choices.get(choice)
            if action:
                action()
            else:
                print("{0} is not a valid choice".format(choice))

    def quit(self):
        print("\nThank you for using this script!\n")
        sys.exit(0)
