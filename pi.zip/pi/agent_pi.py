from agent.cli.menu import *

if __name__ == '__main__':
    Menu().run()
